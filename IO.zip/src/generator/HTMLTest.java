package generator;

public class HTMLTest {

    public static void main(String[] args) {
        HTMLGenerator generator = new HTMLGenerator("OOP2-Tutorium", "Herzlich Willkommen Zum OOP2-Tutorium", "index");
        generator.generateHTML();

    }
}
