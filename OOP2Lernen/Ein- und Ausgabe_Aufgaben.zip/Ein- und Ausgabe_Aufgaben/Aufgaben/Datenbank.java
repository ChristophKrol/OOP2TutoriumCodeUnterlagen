package Aufgaben;

import java.io.*;
import java.util.Hashtable;
import java.util.Scanner;

public class Datenbank {
    private static Hashtable<Integer, String> db;

    static {
        try {
            db = initDatenbank();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Gravierender Fehler beim Laden der Datenbank");
        }
    }

    public static void main(String[] args) throws IOException {
        System.out.println();
        System.out.println("Datenbank-Menu");
        System.out.println("----------------");
        System.out.println("Menu schließen: 0");
        System.out.println("Zeige Daten: 1");
        System.out.println("Füge Daten hinzu: 2");
        System.out.println("Entferne Daten: 3");
        System.out.println("Deine Eingabe: ");

        Scanner input = new Scanner(System.in);

        switch(input.nextInt()) {
            case 0:
                System.out.println("***Das Menu wurde erfolgreich geschlossen***");
                saveDatenbank();
                System.exit(0);
            case 1:
                showData();
                break;
            case 2:
                System.out.println("Bitte geben Sie Schlüssel und Wert, getrennt mit einem Semicolon an");
                input = new Scanner(System.in);
                String[] text = input.nextLine().split(";");
                addData(Integer.parseInt(text[0]),text[1]);
                break;
            case 3:
                System.out.println("Bitte geben Sie den Schlüssel an, um den Wert zu löschen");
                input = new Scanner(System.in);
                removeData(input.nextInt());
                break;
        }
        main(null);
    }

    public static Hashtable<Integer, String> initDatenbank() throws IOException, ClassNotFoundException {
        File file = new File("db.txt");
        if(file.exists()) {
            ObjectInputStream oIS = new ObjectInputStream(new FileInputStream(file));
            System.out.println("***Datenbank wurde geladen***");
            return (Hashtable<Integer, String>) oIS.readObject();
        }
        System.out.println("***Neue Datenbank wurde erstellt***");
        return new Hashtable<Integer, String>();
    }

    public static void addData(int key, String value) {
        db.put(key, value);
        System.out.println("***Daten wurden hinzugefügt***");
    }

    public static void removeData(int key) {
        db.remove(key);
        System.out.println("***Daten wurden entfernt***");
    }

    public static void saveDatenbank() throws IOException {
        ObjectOutputStream oOS = new ObjectOutputStream(new FileOutputStream("db.txt"));
        oOS.writeObject(db);
        oOS.flush();
        oOS.close();
        System.out.println("***Die Datenbank wurde erfolgreich gespeichert***");
    }

    public static void showData() {
        if(db.isEmpty()) {
            System.out.println("***Es existieren keine Daten***");
            return;
        };

        System.out.println();
        System.out.println("Daten:");
        db.forEach((key,value) -> {
            System.out.println(key + " ; " + value);
        });
        System.out.println();
    }
}
