package Aufgaben;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Zamazan {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader("lager.txt"));

        String line;
        String productID = "";
        int istMenge = 0;
        int sollMenge = 0;
        while((line = reader.readLine()) != null) {
            if(line.contains("Produkt ")) {
                productID = line;
                continue;
            }
            if(line.contains("Ist")) {
                istMenge = Integer.parseInt(line.replace("Ist-Menge: ",""));
                continue;
            }
            if(line.contains("Mindest")) {
                sollMenge = Integer.parseInt(line.replace("Mindestbestand: ",""));
                if(sollMenge > istMenge) {
                    System.out.println(
                            productID + " hat den Mindestbestand unterschritten | Bitte "
                            .concat(String.valueOf(sollMenge-istMenge))
                            .concat(" Produkte bestellen")
                    );
                }
                continue;
            }
        }
    }
}
