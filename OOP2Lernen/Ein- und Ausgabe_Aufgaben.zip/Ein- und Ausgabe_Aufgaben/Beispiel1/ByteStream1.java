package Beispiel1;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class ByteStream1 {
    public static void main(String[] args) throws IOException {
        ByteArrayOutputStream a = new ByteArrayOutputStream();
        a.write("Hello".getBytes());

        byte[] c = a.toByteArray();

        for(byte x : c) {
            System.out.print(x + " ");
        }

        System.out.println();

        ByteArrayInputStream d = new ByteArrayInputStream(c);

        int singleByte = 0;
        for(int i = 0; i < d.available();i++) {
            while((singleByte = d.read()) != -1) {
                char temp = (char) singleByte;
                if(Character.isUpperCase(temp)) {
                    System.out.print(Character.toLowerCase(temp) + " ");
                    continue;
                }
                System.out.print(Character.toUpperCase(temp) + " ");
            }
        }
    }
}
