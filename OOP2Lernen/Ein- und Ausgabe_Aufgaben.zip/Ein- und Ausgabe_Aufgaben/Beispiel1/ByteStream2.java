package Beispiel1;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class ByteStream2 {
    public static void main(String[] args) throws IOException {
        String text = "Hello";

        FileOutputStream fOS = new FileOutputStream("data.txt");

        for (int x : text.getBytes()) {
            fOS.write(x);
        }

        fOS.flush();
        fOS.close();

        FileInputStream fIS = new FileInputStream("data.txt");
        int singleByte = 0;
        for (int i = 0; i < fIS.available(); i++) {
            while ((singleByte = fIS.read()) != -1) {
                char temp = (char) singleByte;
                if (Character.isUpperCase(temp)) {
                    System.out.print(Character.toLowerCase(temp) + " ");
                    continue;
                }
                System.out.print(Character.toUpperCase(temp) + " ");
            }
        }

    }
}
