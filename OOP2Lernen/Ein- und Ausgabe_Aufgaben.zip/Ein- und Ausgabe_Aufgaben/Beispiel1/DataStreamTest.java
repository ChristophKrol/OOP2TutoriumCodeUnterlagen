package Beispiel1;

import java.io.*;

public class DataStreamTest {
    public static void main(String[] args) throws IOException {
        DataOutputStream dOS = new DataOutputStream(new FileOutputStream("data.txt"));
        dOS.writeUTF("Hallo!");
        dOS.writeUTF("Günter!");
        dOS.writeBoolean(true);
        dOS.writeDouble(2.99);
        dOS.flush();
        dOS.close();

        DataInputStream dIS = new DataInputStream(new FileInputStream("data.txt"));
        String a = dIS.readUTF();
        String b = dIS.readUTF();
        boolean c = dIS.readBoolean();
        double d = dIS.readDouble();

        System.out.println(a);
        System.out.println(b);
        System.out.println(c);
        System.out.println(d);

    }
}
