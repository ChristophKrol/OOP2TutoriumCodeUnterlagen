package Beispiel2;

import java.io.*;

public class BufferedReaderWriterTest {
    public static void main(String[] args) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter("data.txt"));
        writer.write("Guten Tag!");
        writer.newLine();
        writer.write("Mein Name ist Josef.");
        writer.flush();
        writer.close();

        BufferedReader reader = new BufferedReader(new FileReader("data.txt"));
        String txt;
        while((txt = reader.readLine()) != null) {
            System.out.println(txt);
        }
    }
}
