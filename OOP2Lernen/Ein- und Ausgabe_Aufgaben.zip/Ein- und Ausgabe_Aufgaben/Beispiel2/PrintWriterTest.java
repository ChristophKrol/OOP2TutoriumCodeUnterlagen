package Beispiel2;

import java.io.File;
import java.io.PrintWriter;

public class PrintWriterTest {
    public static void main(String[] args) throws Exception {
        //Data to write on Console using PrintWriter
        PrintWriter writer = new PrintWriter(System.out);
        writer.println("Das ist eine Konsolenausgabe.");
        writer.flush();
        writer.close();

        //Data to write in File using PrintWriter
        PrintWriter writer1 = new PrintWriter(new File("data.txt"));
        writer1.println(2.1 + 2.2);
        writer1.println(true);
        writer1.println('c');

        writer1.flush();
        writer1.close();
    }
}