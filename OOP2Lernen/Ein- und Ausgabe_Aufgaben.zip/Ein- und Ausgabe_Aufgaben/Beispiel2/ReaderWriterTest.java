package Beispiel2;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class ReaderWriterTest {
    public static void main(String[] args) throws IOException {
        FileWriter writer = new FileWriter("data.txt");
        writer.write("Guten Tag!");
        writer.flush();
        writer.close();

        FileReader reader = new FileReader("data.txt");
        int data;
        while((data = reader.read()) != -1) {
            System.out.print((char) data);
        }
    }
}
