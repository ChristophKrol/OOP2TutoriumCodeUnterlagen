package Beispiel3;

public class KlasseA {
    //Das muss hier sein
    public KlasseA() {}

    public KlasseA(int value) {
        System.out.println("Klasse A wurde erzeugt!");
    }
}
