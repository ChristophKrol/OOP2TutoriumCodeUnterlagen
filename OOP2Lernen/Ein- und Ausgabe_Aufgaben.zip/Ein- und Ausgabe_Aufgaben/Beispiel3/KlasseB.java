package Beispiel3;

import java.io.Serializable;

public class KlasseB extends KlasseA implements Serializable {
    public int value;

    public KlasseB(int value) {
        super(value-1);
        this.value = value;
    }
}
