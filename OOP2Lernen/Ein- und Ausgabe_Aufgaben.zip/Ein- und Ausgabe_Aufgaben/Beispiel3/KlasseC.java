package Beispiel3;

import java.io.Serializable;

public class KlasseC extends KlasseB implements Serializable {
    public int value2;

    public KlasseC(int value) {
        super(value-1);
        this.value = value;
    }
}
