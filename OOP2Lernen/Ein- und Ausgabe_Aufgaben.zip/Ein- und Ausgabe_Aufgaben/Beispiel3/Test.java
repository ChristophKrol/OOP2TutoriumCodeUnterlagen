package Beispiel3;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class Test {
    public static void main(String[] args) throws IOException {
        KlasseC temp = new KlasseC(2);

        ObjectOutputStream oOS = new ObjectOutputStream(new FileOutputStream("data.ser"));
        oOS.writeObject(temp);
        oOS.flush();
        oOS.close();
    }
}
