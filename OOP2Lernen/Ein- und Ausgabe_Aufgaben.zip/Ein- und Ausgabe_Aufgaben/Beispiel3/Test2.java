package Beispiel3;

import java.io.*;

public class Test2 {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        ObjectInputStream oIS = new ObjectInputStream(new FileInputStream("data.ser"));
        KlasseC temp = (KlasseC) oIS.readObject();

        System.out.println(temp.value2);
        System.out.println(temp.value);
        //System.out.println(temp.value0);
    }
}
