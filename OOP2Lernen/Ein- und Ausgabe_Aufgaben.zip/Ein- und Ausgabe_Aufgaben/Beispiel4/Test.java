package Beispiel4;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class Test {
    public static void main(String[] args) throws IOException {
        ObjectOutputStream oOS = new ObjectOutputStream(new FileOutputStream("data.ser"));
        oOS.writeObject(new TestKlasse("Version 100"));
        oOS.flush();
        oOS.close();
    }
}
