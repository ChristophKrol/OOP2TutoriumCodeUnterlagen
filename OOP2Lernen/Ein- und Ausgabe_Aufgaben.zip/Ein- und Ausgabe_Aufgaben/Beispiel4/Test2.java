package Beispiel4;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class Test2 {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        ObjectInputStream oIS = new ObjectInputStream(new FileInputStream("data.ser"));

        TestKlasse a = (TestKlasse) oIS.readObject();
        System.out.println(a.text);
    }
}
