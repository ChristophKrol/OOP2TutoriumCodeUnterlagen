package Beispiel4;

import java.io.Serializable;

public class TestKlasse implements Serializable {
    private static final long serialVersionUID = 100L;
    public String text;

    public TestKlasse(String text) {
        this.text = text;
    }
}
