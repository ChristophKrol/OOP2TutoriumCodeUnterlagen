package Aufgaben;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class Aufgabe1 extends JFrame {
    private static final String username = "Max Mustermann";
    private static final String password = "123";
    private static boolean errorIsShown = false;

    public Aufgabe1(String title) throws HeadlessException, IOException {
        super(title);
        setSize(600, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);
        setResizable(false);

        JPanel content = new JPanel();
        content.setSize(600, 600);
        content.setOpaque(false);
        content.setAlignmentX(Component.CENTER_ALIGNMENT);
        content.setLayout(null);
        add(content);

        JTextField usernameField = new JTextField();
        usernameField.setSize(new Dimension(150, 30));
        usernameField.setLocation(225, 200);
        content.add(usernameField);

        JPasswordField passwordField = new JPasswordField();
        passwordField.setSize(new Dimension(150, 30));
        passwordField.setLocation(225, 235);
        passwordField.setEchoChar('*');
        content.add(passwordField);

        JLabel usernameText = new JLabel("Username:");
        usernameText.setSize(new Dimension(150, 30));
        usernameText.setLocation(155, 200);
        content.add(usernameText);

        JLabel passwordText = new JLabel("Password:");
        passwordText.setSize(new Dimension(150, 30));
        passwordText.setLocation(155, 235);
        content.add(passwordText);

        JButton login = new JButton("Anmelden");
        login.setSize(125, 30);
        login.setLocation(238, 270);
        content.add(login);

        login.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (usernameField.getText().equals(username) && new String(passwordField.getPassword()).equals(password)) {
                    System.exit(0);
                }
                try {
                    if (!errorIsShown) {
                        createNotification(content, "Falsche Nutzerdaten!");
                        errorIsShown = true;
                    }
                } catch (InterruptedException interruptedException) {
                    interruptedException.printStackTrace();
                }
            }
        });
        setVisible(true);
    }

    public static void createNotification(JPanel pnl, String text) throws InterruptedException {
        JLabel txt = new JLabel(text);
        txt.setSize(200, 100);
        txt.setLocation(200, 400);
        txt.setFont(new Font("Serif", Font.BOLD, 20));
        pnl.add(txt);
        pnl.repaint();
    }

    public static void main(String[] args) throws IOException {
        new Aufgabe1("Einloggen");
    }
}