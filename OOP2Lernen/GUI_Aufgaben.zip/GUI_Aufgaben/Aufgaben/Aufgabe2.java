package Aufgaben;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Aufgabe2 extends JFrame {

    public Aufgabe2(String title) throws HeadlessException {
        super(title);

        Dimension size = Toolkit.getDefaultToolkit().getScreenSize();
        size.width -= 800;
        size.height -= 600;

        setSize(800,600);
        setLocationRelativeTo(null);
        setUndecorated(true);

        ImageIcon icon = new ImageIcon(getClass().getResource("dulli.jpg"));
        JLabel img = new JLabel(icon);
        add(img);

        img.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                setLocation((int) (Math.random() * size.width + 1),(int) (Math.random() * size.height + 1));
            }
        });

        addWindowFocusListener(new WindowAdapter() {
            @Override
            public void windowLostFocus(WindowEvent e) {
                System.exit(0);
            }
        });

        setVisible(true);
    }

    public static void main(String[] args) {
        new Aufgabe2("Klickspiel");
    }
}
