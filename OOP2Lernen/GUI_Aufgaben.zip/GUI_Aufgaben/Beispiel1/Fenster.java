package Beispiel1;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Fenster extends JFrame {
    public Fenster() {
        super();
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(400,200);
        setLocationRelativeTo(null);
        setLayout(null);

        JButton button = new JButton("Klick mich");
        button.setSize(200,50);
        button.setLocation(100,50);
        add(button);

        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                remove(button);
                repaint();
            }
        });

        setVisible(true);
    }

    public static void main(String[] args) {
        new Fenster();
    }
}
