package Beispiel2;

public class Person {
    public String name;
    public int alter;

    public Person(String name, int alter) {
        this.name = name;
        this.alter = alter;
    }

    public String getName() {
        return name;
    }

    public static void main(String[] args) {
        Person a = new Person("Max",22) {
            @Override
            public String getName() {
                return "Mein Name ist " + name;
            }
        };

        Person b = new Person("Julius",23);

        System.out.println(a.getName());
        System.out.println(b.getName());
    }
}
