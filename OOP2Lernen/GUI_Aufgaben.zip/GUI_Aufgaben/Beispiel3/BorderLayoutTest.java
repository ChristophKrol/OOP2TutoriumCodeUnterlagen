package Beispiel3;

import javax.swing.*;
import java.awt.*;

public class BorderLayoutTest {
    public static void main(String[] args) {
        String[] tbl = {"North","West","Center","East","South"};

        JFrame mainframe = new JFrame("FlowLayoutTest");
        mainframe.setSize(300,200);
        mainframe.setLayout(new BorderLayout());
        mainframe.setLocationRelativeTo(null);

        for(int i = 0;i<5;i++) {
            JButton a = new JButton(String.valueOf(i+1));
            mainframe.add(a,tbl[i]);
        }
        mainframe.setVisible(true);
    }
}
