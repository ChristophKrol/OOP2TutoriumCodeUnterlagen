package Beispiel3;

import javax.swing.*;
import java.awt.*;

public class FlowLayoutTest {
    public static void main(String[] args) {
        JFrame mainframe = new JFrame("FlowLayoutTest");
        mainframe.setSize(300,200);
        mainframe.setLayout(new FlowLayout());
        mainframe.setLocationRelativeTo(null);

        for(int i = 1;i<=9;i++) {
            JButton a = new JButton(String.valueOf(i));
            mainframe.add(a);
        }
        mainframe.setVisible(true);
    }
}
