package Beispiel3;

import javax.swing.*;
import java.awt.*;

public class GridLayoutTest {
    public static void main(String[] args) {

        JFrame mainframe = new JFrame("FlowLayoutTest");
        mainframe.setSize(300,200);
        mainframe.setLayout(new GridLayout(4,5));
        mainframe.setLocationRelativeTo(null);

        for(int i = 1;i<=20;i++) {
            JButton a = new JButton(String.valueOf(i));
            mainframe.add(a);
        }
        mainframe.setVisible(true);
    }
}
