package Beispiel4;

import javax.swing.*;
import java.awt.event.*;
import java.util.concurrent.TimeUnit;

public class WindowAdapterTest extends JDialog{
    public WindowAdapterTest() {
        super();
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(400,200);
        setLocationRelativeTo(null);
        setLayout(null);

        JButton button = new JButton("Klick mich");
        button.setSize(200,50);
        button.setLocation(100,50);
        add(button);

        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                remove(button);
                repaint();
            }
        });

        /*addWindowFocusListener(new WindowFocusListener() {
            @Override
            public void windowLostFocus(WindowEvent e) {
                try {
                    TimeUnit.SECONDS.sleep(1);
                } catch (InterruptedException interruptedException) {
                    interruptedException.printStackTrace();
                }
                setAlwaysOnTop(true);
                toFront();
                requestFocus();
            }
            public void windowGainedFocus(WindowEvent e) {
                setAlwaysOnTop(false);
            }
        });*/

        setVisible(true);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowGainedFocus(WindowEvent e) {
                super.windowGainedFocus(e);
            }

            @Override
            public void windowClosed(WindowEvent e) {
                //Speichere Daten
            }
        });

        addWindowListener(new WindowListener() {
            @Override
            public void windowOpened(WindowEvent e) {

            }

            @Override
            public void windowClosing(WindowEvent e) {

            }

            @Override
            public void windowClosed(WindowEvent e) {
                //Speichere Daten
            }

            @Override
            public void windowIconified(WindowEvent e) {

            }

            @Override
            public void windowDeiconified(WindowEvent e) {

            }

            @Override
            public void windowActivated(WindowEvent e) {

            }

            @Override
            public void windowDeactivated(WindowEvent e) {

            }

        });
    }

    public static void main(String[] args) {
        new WindowAdapterTest();
    }
}
