package Aufgabe1;

public class Brunnen {
    private int wasser;

    public Brunnen(int wasser) {
        this.wasser = wasser;
    }

    public synchronized int getWasser() {
        return wasser;
    }

    public synchronized void setWasser(int wasser) {
        this.wasser = wasser;
    }
}
