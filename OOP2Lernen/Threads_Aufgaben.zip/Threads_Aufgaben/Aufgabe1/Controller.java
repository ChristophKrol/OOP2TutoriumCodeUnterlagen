package Aufgabe1;

import java.util.concurrent.TimeUnit;

public class Controller extends Thread {
    private Brunnen brunnen;
    private Tank tank;

    public Controller(Brunnen brunnen, Tank tank) {
        this.brunnen = brunnen;
        this.tank = tank;
    }

    @Override
    public void run() {
        while (brunnen.getWasser() != 0 || tank.getWasser() != 0) {
            try {
                TimeUnit.SECONDS.sleep(1);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println(brunnen.getWasser());
            System.out.println(tank.getWasser());
            System.out.println();
        }
    }
}
