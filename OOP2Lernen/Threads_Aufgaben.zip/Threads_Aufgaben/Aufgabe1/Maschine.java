package Aufgabe1;

import java.util.concurrent.TimeUnit;

public class Maschine extends Thread{
    private Tank tank;

    public Maschine(Tank tank) {
        this.tank = tank;
    }

    public synchronized void verdampfen() {
        tank.setWasser(tank.getWasser() - 1);
    }

    @Override
    public void run() {
        try {
            TimeUnit.SECONDS.sleep(5);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        while(tank.getWasser() != 0) {
            verdampfen();
            try {
                TimeUnit.MILLISECONDS.sleep(50);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public Tank getTank() {
        return tank;
    }

    public void setTank(Tank tank) {
        this.tank = tank;
    }
}
