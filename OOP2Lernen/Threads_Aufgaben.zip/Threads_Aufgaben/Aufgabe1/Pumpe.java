package Aufgabe1;

import java.util.concurrent.TimeUnit;

public class Pumpe extends Thread{
    private Brunnen brunnen;
    private Tank tank;

    public Pumpe(Brunnen brunnen, Tank tank) {
        this.brunnen = brunnen;
        this.tank = tank;
    }

    public synchronized void pumpen() {
        brunnen.setWasser(brunnen.getWasser() - 1);
        tank.setWasser(tank.getWasser() + 1);
    }

    @Override
    public void run() {
        while(brunnen.getWasser() != 0) {
            pumpen();
            try {
                TimeUnit.MILLISECONDS.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public Brunnen getBrunnen() {
        return brunnen;
    }

    public void setBrunnen(Brunnen brunnen) {
        this.brunnen = brunnen;
    }

    public Tank getTank() {
        return tank;
    }

    public void setTank(Tank tank) {
        this.tank = tank;
    }
}
