package Aufgabe1;

public class Tank {
    private int wasser;

    public synchronized int getWasser() {
        return wasser;
    }

    public synchronized void setWasser(int wasser) {
        this.wasser = wasser;
    }
}
