package Aufgabe1;

public class Test {
    public static void main(String[] args) throws InterruptedException {
        Brunnen brunnen = new Brunnen(100);
        Tank tank = new Tank();
        Pumpe pumpe = new Pumpe(brunnen,tank);
        Maschine maschine = new Maschine(tank);
        Controller controller = new Controller(brunnen,tank);

        pumpe.start();
        maschine.start();
        controller.start();

        pumpe.join();
        maschine.join();
        controller.join();

        System.out.println("Quelle wurde leer gepumpt");
    }
}
