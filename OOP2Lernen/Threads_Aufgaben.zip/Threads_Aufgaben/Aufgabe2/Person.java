package Aufgabe2;

public class Person extends Thread {
    private Stadion stadion;
    private int gebuchtePlaetze;
    private String besucherName;

    public Person(Stadion stadion, String besucherName) {
        this.stadion = stadion;
        this.besucherName = besucherName;
    }

    public void buchen() {
        synchronized (stadion) {
            stadion.setFreiePlaetze(stadion.getFreiePlaetze() - 1);
            gebuchtePlaetze++;
        }
    }

    @Override
    public void run() {
        while (stadion.getFreiePlaetze() > 1) {
            buchen();
        }
    }

    public Stadion getStadion() {
        return stadion;
    }

    public void setStadion(Stadion stadion) {
        this.stadion = stadion;
    }

    public int getGebuchtePlaetze() {
        return gebuchtePlaetze;
    }

    public void setGebuchtePlaetze(int gebuchtePlaetze) {
        this.gebuchtePlaetze = gebuchtePlaetze;
    }

    public String getBesucherName() {
        return besucherName;
    }

    public void setBesucherName(String besucherName) {
        this.besucherName = besucherName;
    }
}
