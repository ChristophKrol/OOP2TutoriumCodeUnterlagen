package Aufgabe2;

public class Stadion {
    private int freiePlaetze;

    public Stadion(int freiePlaetze) {
        this.freiePlaetze = freiePlaetze;
    }

    public int getFreiePlaetze() {
        return freiePlaetze;
    }

    public void setFreiePlaetze(int freiePlaetze) {
        this.freiePlaetze = freiePlaetze;
    }
}
