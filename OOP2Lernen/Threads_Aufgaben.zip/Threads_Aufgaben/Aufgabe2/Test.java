package Aufgabe2;

public class Test {
    public static void main(String[] args) throws InterruptedException {
        Stadion stadion = new Stadion(1000);
        Person p1 = new Person(stadion,"Peter");
        Person p2 = new Person(stadion,"Malte");

        p1.start();
        p2.start();

        p1.join();
        p2.join();

        System.out.println("Vergleich:");
        System.out.println(p1.getBesucherName() + ": " + p1.getGebuchtePlaetze());
        System.out.println(p2.getBesucherName() + ": " + p2.getGebuchtePlaetze());
        System.out.println("Plätze ingesamt: " + (p1.getGebuchtePlaetze() + p2.getGebuchtePlaetze()));
    }
}
