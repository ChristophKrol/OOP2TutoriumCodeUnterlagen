package Beispiel1;

public class ThreadKonstruktion1 extends Thread{
    @Override
    public void run() {
        System.out.println("Thread-Erzeugung durch erben von der Klasse Thread");
    }
}
