package Beispiel1;

public class ThreadKonstruktion2 implements Runnable{
    @Override
    public void run() {
        System.out.println("Thread-Erzeugung durch die Implementierung des Interfaces Runnable");
    }
}
