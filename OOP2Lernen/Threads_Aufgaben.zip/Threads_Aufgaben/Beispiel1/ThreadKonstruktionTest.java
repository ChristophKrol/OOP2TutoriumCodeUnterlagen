package Beispiel1;

public class ThreadKonstruktionTest {
    public static void main(String[] args) {
        ThreadKonstruktion1 a = new ThreadKonstruktion1();
        a.start();

        ThreadKonstruktion2 b = new ThreadKonstruktion2();
        Thread c = new Thread(b);
        c.start();
    }
}
