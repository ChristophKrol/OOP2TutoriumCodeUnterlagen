package Beispiel2;

public class GeschwindigkeitTest {
    public static int limit = 10000000;
    public static int counter = 0;
    public static int counter2 = 0;

    public static long duration1 = 0;
    public static long duration2 = 0;

    public static void main(String[] args) throws InterruptedException {

        long start = System.currentTimeMillis();
        for (int i = counter; counter <= limit; i++) {
            counter++;
        }
        for (int i = counter2; counter2 <= limit; i++) {
            counter2++;
        }
        System.out.println(System.currentTimeMillis() - start);

        counter = 0;
        counter = 2;

        Thread a = new Thread() {
            @Override
            public void run() {
                long start = System.currentTimeMillis();
                for (int j = counter; counter <= limit; j++) {
                    counter++;
                }
                duration1 = System.currentTimeMillis() - start;
            }
        };

        Thread b = new Thread() {
            @Override
            public void run() {
                long start = System.currentTimeMillis();
                for (int j = counter2; counter2 <= limit; j++) {
                    counter2++;
                }
                duration2 = System.currentTimeMillis() - start;
            }
        };

        a.start();
        b.start();
        a.join();
        b.join();
        System.out.println(duration1+duration2);
    }
}
