package Beispiel3;

import java.util.concurrent.TimeUnit;

public class ThreadLocking extends Thread{
    public synchronized void test() throws InterruptedException {
        TimeUnit.SECONDS.sleep(5);
        System.out.println("Test1");
    }

    public synchronized void test2() {
        System.out.println("Test2");
    }
}
