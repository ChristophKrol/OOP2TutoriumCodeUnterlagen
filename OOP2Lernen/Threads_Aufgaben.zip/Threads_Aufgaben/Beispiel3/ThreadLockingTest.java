package Beispiel3;

public class ThreadLockingTest {
    public static void main(String[] args) throws InterruptedException {
        ThreadLocking a = new ThreadLocking();

        Thread b = new Thread() {
            @Override
            public void run() {
                try {
                    a.test();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        };

        Thread c = new Thread() {
            @Override
            public void run() {
                a.test2();
            }
        };

        b.start();
        c.start();

        b.join();
        c.join();
        System.out.println();
        /////////////////////////////

        ThreadLockingTrick d = new ThreadLockingTrick();

        b = new Thread() {
            @Override
            public void run() {
                try {
                    d.test();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        };

        c = new Thread() {
            @Override
            public void run() {
                d.test2();
            }
        };

        b.start();
        c.start();
    }
}
