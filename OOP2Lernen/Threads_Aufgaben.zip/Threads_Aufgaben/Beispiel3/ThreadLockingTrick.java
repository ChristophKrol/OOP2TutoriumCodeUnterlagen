package Beispiel3;

import java.util.concurrent.TimeUnit;

public class ThreadLockingTrick {
    private final static Object LOCK = new Object();

    public void test() throws InterruptedException {
        synchronized (LOCK) {
            TimeUnit.SECONDS.sleep(5);
            System.out.println("Test1");
        }
    }

    public void test2() {
        synchronized (this) {
            System.out.println("Test2");
        }
    }
}
