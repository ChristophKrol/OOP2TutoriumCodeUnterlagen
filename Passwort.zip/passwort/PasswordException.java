package passwort;

class PasswordException extends Exception{
    public PasswordException(){}
    public PasswordException(String message){
        super(message);
    }

}
