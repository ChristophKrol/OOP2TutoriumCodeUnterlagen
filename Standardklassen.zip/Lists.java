import java.util.*;

public class Lists {

    public static void main(String[] args) {
        List<String> list  = new ArrayList<>();

        LinkedList<String> llist = new LinkedList<>();
    }
}
