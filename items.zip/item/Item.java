package item;

public abstract class Item {

    //protected
    int durability;

    public abstract void use();

}
