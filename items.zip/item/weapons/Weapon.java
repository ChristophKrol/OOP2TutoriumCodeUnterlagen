package item.weapons;

import item.Item;

public abstract class Weapon extends Item {

    protected int damage;
    protected int damageMultiplier;


}
