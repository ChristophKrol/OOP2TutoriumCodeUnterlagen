package item.weapons.melee;
import item.weapons.Weapon;

public class Sword extends Weapon {



private void hit(){

}

    @Override
    public void use() {

    }
}
