package item.weapons.range;

import item.weapons.Weapon;

public class Bow extends Weapon {

    int accuracy;

    private void shoot(){

    }


    @Override
    public void use() {

    }
}
