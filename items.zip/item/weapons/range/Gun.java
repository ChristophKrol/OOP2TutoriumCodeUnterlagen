package item.weapons.range;

import java.util.ArrayList;

public class Gun {

    ArrayList<String> magazine = new ArrayList<String>();
}
